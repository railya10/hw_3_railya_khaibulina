package com.company;

public class Main {

    public static void main(String[] args) {
        double[] numbers = {7.3, -3.2, -1.8, -6.2, 7.1, 2.8, 9.9, 6.7, 1.3, 8.2, 4.2, 8.6, 4.1, 2.0, 7.4};
        double lol = 0;
        int haker = 0;
        boolean hook = false;
        for (double nabers : numbers) {
            if (nabers < 0) {
                hook = true;
            } else if (hook) {
                haker++;
                lol += nabers;
            }
        }
        System.out.println(lol / haker);
    }
}
